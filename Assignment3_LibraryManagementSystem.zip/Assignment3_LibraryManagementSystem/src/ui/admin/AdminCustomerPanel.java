/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui.admin;

/**
 *
 * @author xuanliliu
 */

import business.LibrarySystem;
import business.directory.CustomerDirectory;
import business.model.people.Customer;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/** Admin - Customers Tab */
public class AdminCustomerPanel extends JPanel {

    private final LibrarySystem system;
    private final CustomerDirectory cd;

    private JTable tblCustomers;
    private JTextField tfUsername;
    private JTextField tfFullName;
    private JButton btnCreate;
    private JButton btnRefresh;

    public AdminCustomerPanel(LibrarySystem system) {
        this.system = system;
        this.cd = system.getCustomerDirectory();
        initUI();
        loadTable();
        bindEvents();
    }

    private void initUI() {
        setLayout(new BorderLayout());

        // 顶部表格
        tblCustomers = new JTable();
        JScrollPane sp = new JScrollPane(tblCustomers);
        add(sp, BorderLayout.CENTER);

        // 下方表单 + 按钮
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.EAST;
        form.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        tfUsername = new JTextField(12);
        form.add(tfUsername, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.EAST;
        form.add(new JLabel("Full Name:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        tfFullName = new JTextField(12);
        form.add(tfFullName, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        JPanel btnPanel = new JPanel();
        btnCreate = new JButton("Create Customer");
        btnRefresh = new JButton("Refresh");
        btnPanel.add(btnCreate);
        btnPanel.add(btnRefresh);
        form.add(btnPanel, gbc);

        add(form, BorderLayout.SOUTH);
    }

    private void loadTable() {
        DefaultTableModel m = new DefaultTableModel(
                new Object[]{"ID", "Username", "Full Name"}, 0) {
            @Override public boolean isCellEditable(int r,int c){ return false; }
            @Override public Class<?> getColumnClass(int ci){
                return ci==0 ? Integer.class : String.class;
            }
        };
        for (Customer c : cd.getAll()) {
            m.addRow(new Object[]{ c.getId(), c.getUsername(), c.getFullName() });
        }
        tblCustomers.setModel(m);
        tblCustomers.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }

    private void bindEvents() {
        btnRefresh.addActionListener(e -> loadTable());
        btnCreate.addActionListener(e -> onCreate());
    }

    private void onCreate() {
        String username = tfUsername.getText().trim();
        String fullName = tfFullName.getText().trim();
        if (username.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username required");
            return;
        }
        if (fullName.isEmpty()) {
            fullName = username;
        }

        // 通过 CustomerDirectory 创建（内部会去重）
        Customer c;
        try {
            c = cd.create(username, fullName);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
            return;
        }

        // 这里暂时只创建 Customer，不自动建账号（账号你已经在 Configure 里预置了）
        loadTable();
        tfUsername.setText("");
        tfFullName.setText("");
        JOptionPane.showMessageDialog(this, "Customer created: " + c);
    }
}
