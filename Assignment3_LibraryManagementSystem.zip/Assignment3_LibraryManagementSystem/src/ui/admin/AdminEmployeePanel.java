/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui.admin;

/**
 *
 * @author xuanliliu
 */

import business.LibrarySystem;
import business.model.Branch;
import business.model.Library;
import business.model.people.Employee;
import business.security.BranchManagerRole;
import business.security.UserAccount;

import javax.swing.*;
import java.awt.*;

/**
 * Admin Employees 面板：给某个 Branch 创建 Manager + 登录账号
 */
public class AdminEmployeePanel extends JPanel {

    private final LibrarySystem system;

    // UI 组件
    private JComboBox<Branch> cbBranch;
    private JTextField tfName;
    private JTextField tfExp;
    private JTextField tfUsername;
    private JPasswordField pfPassword;
    private JButton btnAssign;

    public AdminEmployeePanel(LibrarySystem system) {
        this.system = system;
        initUI();
        initData();
        bindEvents();
    }

    /** 初始化界面布局 */
    private void initUI() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        // 中间表单区域
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.anchor = GridBagConstraints.WEST;

        cbBranch   = new JComboBox<>();
        tfName     = new JTextField(18);
        tfExp      = new JTextField(18);
        tfUsername = new JTextField(18);
        pfPassword = new JPasswordField(18);

        int row = 0;

        // Branch
        gbc.gridx = 0; gbc.gridy = row;
        form.add(new JLabel("Branch"), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        form.add(cbBranch, gbc);
        row++;

        // Name
        gbc.gridx = 0; gbc.gridy = row;
        gbc.fill = GridBagConstraints.NONE;
        form.add(new JLabel("Name"), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        form.add(tfName, gbc);
        row++;

        // Experience
        gbc.gridx = 0; gbc.gridy = row;
        gbc.fill = GridBagConstraints.NONE;
        form.add(new JLabel("Experience"), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        form.add(tfExp, gbc);
        row++;

        // Username
        gbc.gridx = 0; gbc.gridy = row;
        gbc.fill = GridBagConstraints.NONE;
        form.add(new JLabel("Username"), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        form.add(tfUsername, gbc);
        row++;

        // Password
        gbc.gridx = 0; gbc.gridy = row;
        gbc.fill = GridBagConstraints.NONE;
        form.add(new JLabel("Password"), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        form.add(pfPassword, gbc);
        row++;

        add(form, BorderLayout.CENTER);

        // 底部按钮
        btnAssign = new JButton("Assign Manager + Account");
        JPanel bottom = new JPanel();
        bottom.add(btnAssign);
        add(bottom, BorderLayout.SOUTH);
    }

    /** 把 Branch 加载到下拉框 */
    private void initData() {
        if (system == null) return;

        DefaultComboBoxModel<Branch> model = new DefaultComboBoxModel<>();
        for (Branch b : system.getBranchDirectory().getAll()) {
            model.addElement(b);
        }
        cbBranch.setModel(model);
        // Branch.toString() 已经是 "Name (#id)"，默认显示即可
    }

    /** 绑定按钮事件 */
    private void bindEvents() {
        if (system == null) return;

        btnAssign.addActionListener(e -> onAssign());
    }

    /** 点击 “Assign Manager + Account” */
    private void onAssign() {
        Branch branch = (Branch) cbBranch.getSelectedItem();
        if (branch == null) {
            msg("Please select a branch.");
            return;
        }

        String name      = tfName.getText().trim();
        String expText   = tfExp.getText().trim();
        String username  = tfUsername.getText().trim();
        String password  = new String(pfPassword.getPassword());

        if (name.isEmpty() || expText.isEmpty()
                || username.isEmpty() || password.isEmpty()) {
            msg("Name, experience, username and password are all required.");
            return;
        }

        int exp;
        try {
            exp = Integer.parseInt(expText);
        } catch (NumberFormatException ex) {
            msg("Experience must be an integer.");
            return;
        }

        // 检查用户名是否已存在
        UserAccount existed = system.getUserAccountDirectory().find(username);
        if (existed != null) {
            msg("Username already exists, please choose another one.");
            return;
        }

        // 1) 创建 Employee
        Employee emp = system.getEmployeeDirectory().create(name, exp);

        // 2) 设置为该 Branch 的 manager，同时同步它的 Library
        branch.setManager(emp);
        Library lib = branch.getLibrary();
        if (lib != null) {
            lib.setManager(emp);
        }

        // 3) 创建 BranchManager 账号
        system.getUserAccountDirectory()
              .create(username, password, new BranchManagerRole());

        msg("Manager and account created for branch: " + branch.toString());

        // 4) 清空输入框
        tfName.setText("");
        tfExp.setText("");
        tfUsername.setText("");
        pfPassword.setText("");
    }

    private static void msg(String s) {
        JOptionPane.showMessageDialog(null, s);
    }
}
