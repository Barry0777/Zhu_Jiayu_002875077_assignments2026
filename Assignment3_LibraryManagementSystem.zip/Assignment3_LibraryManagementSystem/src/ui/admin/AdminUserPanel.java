/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui.admin;

/**
 *
 * @author xuanliliu
 */

import business.LibrarySystem;
import business.security.UserAccount;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/** Admin - Users Tab（只读） */
public class AdminUserPanel extends JPanel {

    private final LibrarySystem system;
    private JTable tblUsers;
    private JButton btnRefresh;

    public AdminUserPanel(LibrarySystem system) {
        this.system = system;
        initUI();
        loadTable();
        bindEvents();
    }

    private void initUI() {
        setLayout(new BorderLayout());

        tblUsers = new JTable();
        add(new JScrollPane(tblUsers), BorderLayout.CENTER);

        btnRefresh = new JButton("Refresh");
        JPanel south = new JPanel(new FlowLayout(FlowLayout.CENTER));
        south.add(btnRefresh);
        add(south, BorderLayout.SOUTH);
    }

    private void loadTable() {
        DefaultTableModel m = new DefaultTableModel(
                new Object[]{"Username", "Role"}, 0) {
            @Override public boolean isCellEditable(int r,int c){ return false; }
        };
        for (UserAccount ua : system.getUserAccountDirectory().getAll()) {
            m.addRow(new Object[]{ ua.getUsername(), ua.getRole().getName() });
        }
        tblUsers.setModel(m);
        tblUsers.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }

    private void bindEvents() {
        btnRefresh.addActionListener(e -> loadTable());
    }
}
