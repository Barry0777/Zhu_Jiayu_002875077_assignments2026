/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package ui.customer;

import business.LibrarySystem;
import business.model.Rental.RentalRecord;
import business.model.Rental.RentalStatus;


import javax.swing.*;
/**
 *
 * @author xuanliliu
 */
public class CustomerWorkAreaPanel extends javax.swing.JPanel {
private final LibrarySystem system;
    private final String username;
    
    private javax.swing.JPanel historyPanel;
    private javax.swing.JTable tblHistory;
    private javax.swing.JScrollPane spHistory;
    private javax.swing.JComboBox<business.model.Branch> cbBranch;


    public CustomerWorkAreaPanel() {
    this.system = null;
    this.username = null;
    initComponents();
}
    
    public CustomerWorkAreaPanel(business.LibrarySystem system, String username) {
    this.system = system;
    this.username = username;
    initComponents();

    // tab 标题改成 Browse / Return / History 风格
    tabbed.setTitleAt(0, "Browse");
    tabbed.setTitleAt(1, "Return");
    jLabel2.setText("Return");

    // 按钮文字改成 Rent Book / Logout
    btnBrowse.setText("Rent Book");
    jButton1.setText("Logout");

    // ★ 重建 Browse 页布局：上 Branch，下按钮，中间表格
    rebuildBrowseTabLayout();

    // ★ 初始化 Branch 下拉框
    initBranchCombo();

    // 初始化三个 tab
    initBrowseTab();    // 里面会 reloadBrowseTable
    initRentalsTab();   // 里面会创建 History tab 并加载数据
    bindCustomerEvents();
}
    
    /** 把 Browse 页改成：上 Branch 下拉，中间表格，底部按钮（Rent Book + Logout） */
private void rebuildBrowseTabLayout() {
    // 顶部：Branch 下拉
    javax.swing.JPanel top = new javax.swing.JPanel(
            new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
    javax.swing.JLabel lblBranch = new javax.swing.JLabel("Branch:");
    cbBranch = new javax.swing.JComboBox<>();
    top.add(lblBranch);
    top.add(cbBranch);

    // 底部：Rent Book + Logout
    javax.swing.JPanel bottom = new javax.swing.JPanel(
            new java.awt.FlowLayout(java.awt.FlowLayout.CENTER));
    bottom.add(btnBrowse);
    bottom.add(jButton1);

    // 原来的 browsePanel 里还有 Keyword / Search 之类控件，
    // 我们全部清掉，用 BorderLayout 重新布置
    browsePanel.removeAll();
    browsePanel.setLayout(new java.awt.BorderLayout());
    browsePanel.add(top,    java.awt.BorderLayout.NORTH);
    browsePanel.add(spBrowse, java.awt.BorderLayout.CENTER);
    browsePanel.add(bottom, java.awt.BorderLayout.SOUTH);

    browsePanel.revalidate();
    browsePanel.repaint();
}


/** 初始化 Branch 下拉选项，并联动刷新表格 */
private void initBranchCombo() {
    if (system == null) return;

    javax.swing.DefaultComboBoxModel<business.model.Branch> model =
            new javax.swing.DefaultComboBoxModel<>();
    for (business.model.Branch b : system.getBranchDirectory().getAll()) {
        model.addElement(b);
    }
    cbBranch.setModel(model);

    // 显示成 “Boston (Branch #1)” 这种
    cbBranch.setRenderer((list, value, index, isSelected, cellHasFocus) ->
            new javax.swing.JLabel(
                    value == null
                            ? ""
                            : value.getName() + " (Branch #" + value.getId() + ")"
            ));

    // 选择分馆时刷新 Browse 表
    cbBranch.addActionListener(e -> reloadBrowseTable(""));
}

/** 根据 Book 找到它所在的 Branch（通过 library 反查） */
private business.model.Branch findBranchOfBook(business.model.book.Book b) {
    if (b == null || system == null) return null;
    for (business.model.Branch br : system.getBranchDirectory().getAll()) {
        if (br.getLibrary() == b.getLibrary()) {
            return br;
        }
    }
    return null;
}



 private void initBrowseTab() {
        if (tblBrowse.getSelectionModel() != null) {
            tblBrowse.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        }
        reloadBrowseTable("");
    }

    private void reloadBrowseTable(String keyword) {
    if (system == null) return; // 设计器预览

    // 当前选中的分馆（可为空，表示不过滤）
    business.model.Branch selectedBranch =
            (cbBranch == null ? null : (business.model.Branch) cbBranch.getSelectedItem());

    javax.swing.table.DefaultTableModel model = new javax.swing.table.DefaultTableModel(
            new Object[]{"SN", "Book", "Author", "Branch", "Available"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
        @Override public Class<?> getColumnClass(int columnIndex) {
            // 最后一列用 Boolean 才能显示 true/false
            return columnIndex == 4 ? Boolean.class : Object.class;
        }
    };

    for (business.model.book.Book b : system.getBookDirectory().getAll()) {
        // 先拿到这本书所在分馆
        business.model.Branch bookBranch = findBranchOfBook(b);

        // 若下拉选了某个分馆，则只显示该分馆的书
        if (selectedBranch != null && bookBranch != selectedBranch) {
            continue;
        }

        // （可选）如果你想保留关键字过滤，可以用书名/作者名匹配 keyword：
        if (keyword != null && !keyword.isEmpty()) {
            String k = keyword.toLowerCase();
            String name   = b.getName() == null ? "" : b.getName().toLowerCase();
            String author = (b.getAuthor() == null ? "" : b.getAuthor().getName()).toLowerCase();
            if (!(name.contains(k) || author.contains(k))) {
                continue;
            }
        }

        model.addRow(new Object[]{
                b.getSerial(),                        // SN
                b,                                    // Book（toString 显示）
                b.getAuthor() == null ? "-" : b.getAuthor().getName(),
                bookBranch == null ? "-" : bookBranch.getName(),
                Boolean.valueOf(!b.isRented())       // Available = 没被借出
        });
    }

    tblBrowse.setModel(model);
    if (tblBrowse.getColumnModel().getColumnCount() > 0) {
        // 让 Book 列宽一点
        tblBrowse.getColumnModel().getColumn(1).setPreferredWidth(220);
    }
}


    // ========= Rentals Tab =========
    private void initRentalsTab() {
        if (tblRentals.getSelectionModel() != null) {
            tblRentals.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        }
        
        initHistoryTab();

    // ★ 首次加载 Return + History 两个表的数据
    reloadMyRentals();
    }

    private void reloadMyRentals() {
    if (system == null) return;

    // ---- 先做逾期判定 ----
    java.time.LocalDate today = java.time.LocalDate.now();
    for (RentalRecord r : system.getRentalDirectory().getAll()) {
        if (r.getReturnDate() == null && today.isAfter(r.getDueDate())) {
            r.setStatus(RentalStatus.OVERDUE);
        }
    }

    // Return 表（只显示当前未归还）
    javax.swing.table.DefaultTableModel modelReturn = new javax.swing.table.DefaultTableModel(
            new Object[]{"Book","Start","Due","Return","Status"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };

    // History 表（显示所有记录）
    javax.swing.table.DefaultTableModel modelHistory = new javax.swing.table.DefaultTableModel(
            new Object[]{"Book","Start","Due","Return","Status"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };

    for (RentalRecord r : system.getRentalDirectory().getAll()) {
        if (!username.equals(r.getCustomerUsername())) continue;

        Object[] row = new Object[]{
                r.getBook(),
                r.getStartDate(),
                r.getDueDate(),
                r.getReturnDate() == null ? "-" : r.getReturnDate(),
                r.getStatus()
        };

        // 所有记录进 History
        modelHistory.addRow(row);

        // 只有 active（BORROWED） 的进 Return
        if (r.isActive()) {
            modelReturn.addRow(row);
        }
    }

    // 填充 Return 表（tblRentals）
    tblRentals.setModel(modelReturn);
    if (tblRentals.getColumnModel().getColumnCount() > 0) {
        tblRentals.getColumnModel().getColumn(0).setPreferredWidth(220);
    }

    // 填充 History 表
    if (tblHistory != null) {
        tblHistory.setModel(modelHistory);
        if (tblHistory.getColumnModel().getColumnCount() > 0) {
            tblHistory.getColumnModel().getColumn(0).setPreferredWidth(220);
        }
    }
}

/** 创建 History tab（只负责 UI 布局，数据之后由 reloadMyRentals 填充） */
private void initHistoryTab() {
    historyPanel = new javax.swing.JPanel();
    historyPanel.setLayout(new java.awt.BorderLayout());

    tblHistory = new javax.swing.JTable();
    spHistory = new javax.swing.JScrollPane(tblHistory);
    historyPanel.add(spHistory, java.awt.BorderLayout.CENTER);

    // 追加到 tabbed 最后：Browse(0)、Return(1)、History(2)
    tabbed.addTab("History", historyPanel);
}


    // ========= 事件绑定 =========
    private void bindCustomerEvents() {
        if (system == null) return; // 设计器预览

        btnSearch.addActionListener(e -> reloadBrowseTable(tfKeyword.getText().trim()));
        btnBrowse.addActionListener(e -> onBorrow());
        btnReturn.addActionListener(e -> onReturn());
    }

    // ========= 借书 =========
    private void onBorrow() {
        if (system == null) return;

        int row = tblBrowse.getSelectedRow();
        if (row < 0) { msg("Please select a book."); return; }

        business.model.book.Book b = (business.model.book.Book) tblBrowse.getValueAt(row, 0);
        if (b.isRented()) { msg("This book has already been borrowed."); return; }

    // ---- 借阅约束：上限与重复借 ----
        int activeCount = 0;
        for (business.model.Rental.RentalRecord r : system.getRentalDirectory().getAll()) {
            if (!username.equals(r.getCustomerUsername())) continue;
            if (r.isActive()) {
                activeCount++;
                if (r.getBook() == b) {
                    msg("You already borrowed this book and haven't returned it.");
                    return;
                }
            }
        }
        if (activeCount >= 3) {
            msg("You already have 3 active loans. Please return before borrowing more.");
            return;
        }

    // 1) 标记书已借出
        b.setRented(true);

    // 2) 建立借阅记录
        java.time.LocalDate start = java.time.LocalDate.now();
        java.time.LocalDate due   = start.plusDays(14);
        business.model.Rental.RentalRecord rec =
                system.getRentalDirectory().create(b, username, start, due);
        rec.setStatus(business.model.Rental.RentalStatus.BORROWED);

    // 3) 刷新
        reloadBrowseTable(tfKeyword.getText().trim());
        reloadMyRentals();

        msg("Borrowed: " + b.toString());
    }



    // ========= 归还 =========
    private void onReturn() {
        if (system == null) return;

        int row = tblRentals.getSelectedRow();
        if (row < 0) { msg("Please select a rental to return."); return; }

        business.model.book.Book b =
                (business.model.book.Book) tblRentals.getValueAt(row, 0);

    // 统一使用大写 R 的包名：business.model.Rental
        business.model.Rental.RentalRecord target = null;
        for (business.model.Rental.RentalRecord r : system.getRentalDirectory().getAll()) {
            boolean isMine = username != null && username.equals(r.getCustomerUsername());
            boolean isSameBook = r.getBook() == b;
            boolean isBorrowed = r.getStatus() == business.model.Rental.RentalStatus.BORROWED;
            if (isMine && isSameBook && isBorrowed) { target = r; break; }
        }   
        if (target == null) { msg("No active record found for this book."); return; }

        b.setRented(false);
        target.setReturnDate(java.time.LocalDate.now());
        target.setStatus(business.model.Rental.RentalStatus.RETURNED);

        reloadBrowseTable(tfKeyword.getText().trim());
        reloadMyRentals();
        msg("Returned: " + b.toString());
    }

    // ========= 弹窗工具 =========
    private static void msg(String s) {
        javax.swing.JOptionPane.showMessageDialog(null, s);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tabbed = new javax.swing.JTabbedPane();
        browsePanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tfKeyword = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        btnBrowse = new javax.swing.JButton();
        spBrowse = new javax.swing.JScrollPane();
        tblBrowse = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        rentalsPanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        spRentals = new javax.swing.JScrollPane();
        tblRentals = new javax.swing.JTable();
        btnReturn = new javax.swing.JButton();

        jLabel1.setText("KeyWord");

        btnSearch.setText("Search");

        btnBrowse.setText("Borrow");

        tblBrowse.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Book", "Author", "Page", "Language", "Registered", "Rented"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.Object.class, java.lang.Boolean.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        spBrowse.setViewportView(tblBrowse);

        jButton1.setText("Log out");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout browsePanelLayout = new javax.swing.GroupLayout(browsePanel);
        browsePanel.setLayout(browsePanelLayout);
        browsePanelLayout.setHorizontalGroup(
            browsePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(browsePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(tfKeyword, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSearch)
                .addGap(49, 49, 49))
            .addGroup(browsePanelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(spBrowse, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
            .addGroup(browsePanelLayout.createSequentialGroup()
                .addGap(89, 89, 89)
                .addComponent(btnBrowse)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(78, 78, 78))
        );
        browsePanelLayout.setVerticalGroup(
            browsePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(browsePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(browsePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(tfKeyword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearch))
                .addGap(41, 41, 41)
                .addComponent(spBrowse, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addGroup(browsePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBrowse)
                    .addComponent(jButton1))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        tabbed.addTab("Browse", browsePanel);

        jLabel2.setText("My Rentals");

        tblRentals.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Book", "Start", "Due", "Return", "Status"
            }
        ));
        spRentals.setViewportView(tblRentals);

        btnReturn.setText("Return");

        javax.swing.GroupLayout rentalsPanelLayout = new javax.swing.GroupLayout(rentalsPanel);
        rentalsPanel.setLayout(rentalsPanelLayout);
        rentalsPanelLayout.setHorizontalGroup(
            rentalsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rentalsPanelLayout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(rentalsPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnReturn)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(spRentals, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        rentalsPanelLayout.setVerticalGroup(
            rentalsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rentalsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(31, 31, 31)
                .addComponent(spRentals, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnReturn)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabbed.addTab("My Rentals", rentalsPanel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbed, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(tabbed)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        java.awt.Window win = javax.swing.SwingUtilities.getWindowAncestor(this);
    if (win != null) {
        win.dispose();                      // 关掉 WorkAreaFrame
    }
    new ui.LoginFrame().setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel browsePanel;
    private javax.swing.JButton btnBrowse;
    private javax.swing.JButton btnReturn;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel rentalsPanel;
    private javax.swing.JScrollPane spBrowse;
    private javax.swing.JScrollPane spRentals;
    private javax.swing.JTabbedPane tabbed;
    private javax.swing.JTable tblBrowse;
    private javax.swing.JTable tblRentals;
    private javax.swing.JTextField tfKeyword;
    // End of variables declaration//GEN-END:variables
}
