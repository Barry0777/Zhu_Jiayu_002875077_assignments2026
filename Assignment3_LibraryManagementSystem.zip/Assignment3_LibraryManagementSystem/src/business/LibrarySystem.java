// business/LibrarySystem.java
package business;

import business.directory.*;  // 别忘了导入

public class LibrarySystem {

    private final UserAccountDirectory userAccountDirectory = new UserAccountDirectory();
    private final EmployeeDirectory    employeeDirectory    = new EmployeeDirectory();
    private final BranchDirectory      branchDirectory      = new BranchDirectory();
    private final LibraryDirectory     libraryDirectory     = new LibraryDirectory();
    private final BookDirectory        bookDirectory        = new BookDirectory();
    private final RentalDirectory      rentalDirectory      = new RentalDirectory();
    private final AuthorDirectory      authorDirectory      = new AuthorDirectory();

    // ★ 新增：客户目录
    private final CustomerDirectory    customerDirectory    = new CustomerDirectory();

    public UserAccountDirectory getUserAccountDirectory() { return userAccountDirectory; }
    public EmployeeDirectory    getEmployeeDirectory()    { return employeeDirectory; }
    public BranchDirectory      getBranchDirectory()      { return branchDirectory; }
    public LibraryDirectory     getLibraryDirectory()     { return libraryDirectory; }
    public BookDirectory        getBookDirectory()        { return bookDirectory; }
    public RentalDirectory      getRentalDirectory()      { return rentalDirectory; }
    public AuthorDirectory      getAuthorDirectory()      { return authorDirectory; }
    // ★ 新增 getter
    public CustomerDirectory    getCustomerDirectory()    { return customerDirectory; }
}
