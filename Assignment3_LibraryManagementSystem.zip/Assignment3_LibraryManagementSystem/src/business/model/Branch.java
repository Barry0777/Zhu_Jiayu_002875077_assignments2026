/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package business.model;

/**
 *
 * @author xuanliliu
 */

import business.model.people.Employee;

public class Branch {
    private static int BRANCH_COUNTER = 1;
    private final int id;
    private String name;

    private Library library;   // 一个分馆对应一个 Library
    private Employee manager;  // 分馆经理

    public Branch() { this("Branch"); }

    public Branch(String name) {
        this.id = BRANCH_COUNTER++;
        this.name = name;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    // ★ 这两个就是 ConfigureTheBusiness 要调用的方法
    public Library getLibrary() { return library; }
    public void setLibrary(Library library) { this.library = library; }

    public Employee getManager() { return manager; }
    public void setManager(Employee manager) { this.manager = manager; }

    @Override
    public String toString() { return name + " (#" + id + ")"; }
}
