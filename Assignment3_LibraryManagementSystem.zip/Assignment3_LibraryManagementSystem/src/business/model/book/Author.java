/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package business.model.book;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/** 作者实体（完整版） */
public class Author {

    // —— 自增主键 —— //
    private static int ID_GEN = 1;

    // —— 字段 —— //
    private final int id;             // 作者唯一 ID
    private String name;              // 姓名（必填）
    private String nationality;       // 国籍（可选）
    private String biography;         // 简介（可选）
    private Integer birthYear;        // 出生年（可选，>= 0）
    private Integer deathYear;        // 去世年（可选，>= birthYear）

    /** 作品列表（只存引用，不复制） */
    private final List<Book> works = new ArrayList<>();

    // —— 构造 —— //
    public Author(String name) {
        this(name, null, null, null, null);
    }

    public Author(String name, String nationality, String biography,
                  Integer birthYear, Integer deathYear) {
        this.id = ID_GEN++;
        setName(name);
        this.nationality = trimOrNull(nationality);
        this.biography   = trimOrNull(biography);
        setBirthYear(birthYear);
        setDeathYear(deathYear);
    }

    // —— Getter / Setter —— //
    public int getId() { return id; }

    public String getName() { return name; }
    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Author name cannot be empty.");
        }
        this.name = name.trim();
    }

    public String getNationality() { return nationality; }
    public void setNationality(String nationality) {
        this.nationality = trimOrNull(nationality);
    }

    public String getBiography() { return biography; }
    public void setBiography(String biography) {
        this.biography = trimOrNull(biography);
    }

    public Integer getBirthYear() { return birthYear; }
    public void setBirthYear(Integer birthYear) {
        if (birthYear != null && birthYear < 0) {
            throw new IllegalArgumentException("birthYear must be >= 0.");
        }
        this.birthYear = birthYear;
        // 如果 deathYear 已有值，保持 birth <= death 的不变量
        if (this.deathYear != null && this.birthYear != null && this.deathYear < this.birthYear) {
            throw new IllegalArgumentException("deathYear must be >= birthYear.");
        }
    }

    public Integer getDeathYear() { return deathYear; }
    public void setDeathYear(Integer deathYear) {
        if (deathYear != null && deathYear < 0) {
            throw new IllegalArgumentException("deathYear must be >= 0.");
        }
        if (deathYear != null && this.birthYear != null && deathYear < this.birthYear) {
            throw new IllegalArgumentException("deathYear must be >= birthYear.");
        }
        this.deathYear = deathYear;
    }

    /** 不可变视图，外部不可直接改 */
    public List<Book> getWorks() { return Collections.unmodifiableList(works); }

    // —— 关系维护（双向） —— //
    /** 把作品加入作者名下；自动维护 Book.author */
    public void addBook(Book book) {
        if (book == null) return;
        if (!works.contains(book)) {
            works.add(book);
        }
        if (book.getAuthor() != this) {
            book.setAuthor(this); // 反向维护
        }
    }

    /** 从作者名下移除作品；自动清理 Book.author */
    public void removeBook(Book book) {
        if (book == null) return;
        works.remove(book);
        if (book.getAuthor() == this) {
            book.setAuthor(null);
        }
    }

    // —— 展示 & 对比 —— //
    @Override
    public String toString() {
        return name + " (ID:" + id + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Author)) return false;
        Author author = (Author) o;
        return id == author.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    // —— 工具 —— //
    private static String trimOrNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }
}
