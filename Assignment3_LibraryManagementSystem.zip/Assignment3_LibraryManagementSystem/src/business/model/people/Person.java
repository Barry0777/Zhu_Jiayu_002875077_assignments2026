/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package business.model.people;

/**
 *
 * @author xuanliliu
 */

public class Person {
    private static int COUNTER = 1;
    private final int id;
    private String name;

    public Person() { this("Unnamed"); }

    public Person(String name) {
        this.id = COUNTER++;
        this.name = name;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}
