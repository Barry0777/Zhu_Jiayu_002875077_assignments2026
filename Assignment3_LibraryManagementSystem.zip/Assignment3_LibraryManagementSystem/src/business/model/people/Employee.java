/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package business.model.people;

/**
 *
 * @author xuanliliu
 */

public class Employee extends Person {
    private static int EMP_COUNTER = 1000;
    private final int employeeId;
    private int experience; // 年限

    /** 无参构造（有些 GUI 工具会用到） */
    public Employee() {
        this("Unnamed", 0);
    }

    /** 有参构造 —— 这就是 ConfigureTheBusiness 在用的 */
    public Employee(String name, int experience) {
        super(name);                 // 调用 Person(String name)
        this.employeeId = EMP_COUNTER++;
        this.experience = experience;
    }

    public int getEmployeeId() { return employeeId; }
    public int getExperience() { return experience; }
    public void setExperience(int exp) { this.experience = exp; }
}
