/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package business.model.people;

/**
 *
 * @author xuanliliu
 */

public class Customer {
  private static int COUNTER=1; private final int id;
  private String username; private String fullName; // 可选
  public Customer(String username,String fullName){ this.id=COUNTER++; this.username=username; this.fullName=fullName; }
  public int getId(){return id;} public String getUsername(){return username;}
  public String getFullName(){return fullName;} public void setFullName(String n){this.fullName=n;}
  @Override public String toString(){ return (fullName==null? username: fullName) + " (#"+id+")"; }
}
