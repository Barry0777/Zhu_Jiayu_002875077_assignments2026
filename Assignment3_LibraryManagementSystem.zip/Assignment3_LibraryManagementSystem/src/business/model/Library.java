/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package business.model;

/**
 *
 * @author xuanliliu
 */

import business.directory.AuthorDirectory;
import business.directory.BookDirectory;
import business.directory.RentalDirectory;
import business.model.people.Employee;

public class Library {
    private static int LIB_COUNTER = 1;
    private final int id;
    private String buildingNo;

    // 目录：后面 UI 会用到；现在先给最小实现
    private final AuthorDirectory authorDirectory = new AuthorDirectory();
    private final BookDirectory bookDirectory = new BookDirectory();
    private final RentalDirectory rentalDirectory = new RentalDirectory();

    private Employee manager;

    public Library() { this("Building"); }

    public Library(String buildingNo) {
        this.id = LIB_COUNTER++;
        this.buildingNo = buildingNo;
    }

    public int getId() { return id; }
    public String getBuildingNo() { return buildingNo; }
    public void setBuildingNo(String buildingNo) { this.buildingNo = buildingNo; }

    public AuthorDirectory getAuthorDirectory() { return authorDirectory; }
    public BookDirectory getBookDirectory() { return bookDirectory; }
    public RentalDirectory getRentalDirectory() { return rentalDirectory; }

    public Employee getManager() { return manager; }
    public void setManager(Employee manager) { this.manager = manager; }

    @Override
    public String toString() { return buildingNo + " (#" + id + ")"; }
}
