/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package business.security;

import business.LibrarySystem;
import javax.swing.*;
import ui.admin.AdminWorkAreaPanel;
/**
 *
 * @author xuanliliu
 */

import javax.swing.JLabel;
import javax.swing.JPanel;

public class SystemAdminRole extends Role {
    @Override
public javax.swing.JPanel createWorkArea(business.LibrarySystem system, String username) {
    return new ui.admin.AdminMainPanel(system);
}
}