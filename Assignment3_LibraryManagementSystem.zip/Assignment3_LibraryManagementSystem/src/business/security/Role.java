/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package business.security;

/**
 *
 * @author xuanliliu
 */

import business.LibrarySystem;
import javax.swing.JPanel;

/** 抽象角色：各角色返回自己的工作台 */
public abstract class Role {
    // ★ 统一改成带上下文参数
    public abstract JPanel createWorkArea(LibrarySystem system, String username);
    public String getName(){ return getClass().getSimpleName(); }
}