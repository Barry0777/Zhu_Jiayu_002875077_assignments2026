package business.security;

import business.LibrarySystem;
import business.model.Branch;
import business.model.Library;
import ui.manager.ManagerWorkAreaPanel;

import javax.swing.JPanel;

public class BranchManagerRole extends Role {

    @Override
    public JPanel createWorkArea(LibrarySystem system, String username) {
        // 1) 尝试根据登录名找到他管理的分馆 -> 所属 Library
        Library lib = null;

        // 如果你已经把账号与 Employee 绑定了，可以在这里按 Employee 来精确比对；
        // 目前先按“随便挑一个有经理的分馆”作为兜底，保证能跑起来。
        for (Branch b : system.getBranchDirectory().getAll()) {
            if (b.getLibrary() != null) {
                lib = b.getLibrary();
                break;
            }
        }

        // 2) 如果还没找到，就拿 LibraryDirectory 里的第一个库兜底
        if (lib == null && !system.getLibraryDirectory().getAll().isEmpty()) {
            lib = system.getLibraryDirectory().getAll().get(0);
        }

        // 3) 传入 system + library
        return new ManagerWorkAreaPanel(system, lib);
    }
}
