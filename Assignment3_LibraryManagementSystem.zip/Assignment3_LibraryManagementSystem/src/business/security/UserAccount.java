/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package business.security;

/**
 *
 * @author xuanliliu
 */

public class UserAccount {
    private final String username;
    private final String password;
    private final Role role;
    
     private Integer libraryId;

    public UserAccount(String username, String password, Role role) {
        this.username = username;
        this.password = password;
        this.role = role;
    }
    public String getUsername() { return username; }
    public Role getRole() { return role; }
    public Integer getLibraryId() { return libraryId; }
    public void setLibraryId(Integer libraryId) { this.libraryId = libraryId;}

    /** 简单用户名+密码校验 */
    public boolean authenticate(String u, String p) {
        return this.username.equals(u) && this.password.equals(p);
    }
}
